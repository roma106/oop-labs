﻿using Itmo.ObjectOrientedProgramming.Lab1.Transport;

namespace Itmo.ObjectOrientedProgramming.Lab1.Routing;

public class RouteSheet
{
    public IReadOnlyCollection<IRouteStage> Stages { get; }

    public RouteSheet(IReadOnlyCollection<IRouteStage> stages)
    {
        Stages = stages;
    }

    public abstract record RouteSheetResult
    {
        private RouteSheetResult() { }

        public sealed record Success(double Time) : RouteSheetResult;

        public sealed record Err() : RouteSheetResult;
    }

    public RouteSheetResult DoRouteSheet(Truck truck)
    {
        double overallTime = 0;
        foreach (IRouteStage stage in Stages)
        {
            StageResult result = stage.DoStage(truck);
            if (result is not StageResult.Success success)
            {
                return new RouteSheetResult.Err();
            }

            overallTime += success.StageTimeMinutes;
        }

        return new RouteSheetResult.Success(overallTime);
    }
}